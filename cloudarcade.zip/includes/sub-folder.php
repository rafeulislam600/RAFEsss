<?php

/* Used for sub-folder installation (non-root) */

define( "SUB_FOLDER", "");

//define( "SUB_FOLDER", "your_folder/");
//Don't forget to put a "/" after folder name
//Leave it empty for root usage

?>